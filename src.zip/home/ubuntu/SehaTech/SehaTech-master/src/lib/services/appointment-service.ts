import { 
  collection, 
  doc, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  getDocs, 
  getDoc,
  query, 
  where, 
  orderBy, 
  limit,
  startAfter,
  Timestamp,
  writeBatch,
  onSnapshot,
  serverTimestamp
} from "firebase/firestore"
import { ref, set, push, onValue, off } from "firebase/database"
import { db, rtdb } from "@/lib/firebase"

export interface CreateAppointmentRequest {
  patientId: string
  doctorId: string
  date: string
  time: string
  duration?: number
  type: 'consultation' | 'follow-up' | 'emergency'
  priority: 'low' | 'medium' | 'high' | 'urgent'
  reason: string
  notes?: string
  symptoms?: string
}

export interface UpdateAppointmentRequest {
  id: string
  status?: 'scheduled' | 'confirmed' | 'in-progress' | 'completed' | 'cancelled' | 'no-show'
  notes?: string
  actualStartTime?: string
  actualEndTime?: string
  diagnosis?: string
  prescription?: string
  followUpRequired?: boolean
  followUpDate?: string
}

export interface AppointmentFilters {
  doctorId?: string
  patientId?: string
  status?: string
  date?: string
  dateRange?: {
    start: string
    end: string
  }
  type?: string
  priority?: string
}

export interface TimeSlot {
  time: string
  available: boolean
  appointmentId?: string
  patientName?: string
}

export interface WaitingListEntry {
  patientId: string
  doctorId: string
  preferredDate?: string
  preferredTime?: string
  priority: 'low' | 'medium' | 'high' | 'urgent'
  reason: string
  createdAt: Timestamp
}

class AppointmentService {
  private appointmentsCollection = collection(db, 'appointments')
  private patientsCollection = collection(db, 'patients')
  private doctorsCollection = collection(db, 'doctors')
  private waitingListCollection = collection(db, 'waiting_list')

  // إنشاء موعد جديد
  async createAppointment(appointmentData: CreateAppointmentRequest, createdBy: string) {
    try {
      // التحقق من توفر الوقت
      const isAvailable = await this.checkTimeSlotAvailability(
        appointmentData.doctorId,
        appointmentData.date,
        appointmentData.time
      )

      if (!isAvailable) {
        throw new Error('الوقت المحدد غير متاح')
      }

      // الحصول على بيانات المريض والطبيب
      const [patientDoc, doctorDoc] = await Promise.all([
        getDoc(doc(this.patientsCollection, appointmentData.patientId)),
        getDoc(doc(this.doctorsCollection, appointmentData.doctorId))
      ])

      if (!patientDoc.exists() || !doctorDoc.exists()) {
        throw new Error('المريض أو الطبيب غير موجود')
      }

      const patient = patientDoc.data()
      const doctor = doctorDoc.data()

      // إنشاء الموعد
      const appointment = {
        ...appointmentData,
        patientName: patient.personalInfo.name,
        doctorName: doctor.personalInfo.name,
        doctorSpecialty: doctor.personalInfo.specialty,
        status: {
          current: 'scheduled' as const,
          history: [{
            status: 'scheduled',
            timestamp: serverTimestamp(),
            changedBy: createdBy,
            reason: 'موعد جديد'
          }]
        },
        financial: {
          fee: doctor.financialInfo.consultationFee,
          paid: false
        },
        metadata: {
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
          createdBy,
          remindersSent: 0
        }
      }

      const docRef = await addDoc(this.appointmentsCollection, appointment)

      // تحديث الإحصائيات في الوقت الفعلي
      await this.updateRealTimeStats()

      // إرسال إشعار
      await this.sendAppointmentNotification(docRef.id, 'created')

      return { id: docRef.id, ...appointment }
    } catch (error) {
      console.error('Error creating appointment:', error)
      throw error
    }
  }

  // تحديث موعد
  async updateAppointment(updateData: UpdateAppointmentRequest, updatedBy: string) {
    try {
      const appointmentRef = doc(this.appointmentsCollection, updateData.id)
      const appointmentDoc = await getDoc(appointmentRef)

      if (!appointmentDoc.exists()) {
        throw new Error('الموعد غير موجود')
      }

      const currentData = appointmentDoc.data()
      const updates: any = {
        ...updateData,
        metadata: {
          ...currentData.metadata,
          updatedAt: serverTimestamp()
        }
      }

      // إضافة تحديث الحالة إلى التاريخ
      if (updateData.status && updateData.status !== currentData.status.current) {
        updates.status = {
          current: updateData.status,
          history: [
            ...currentData.status.history,
            {
              status: updateData.status,
              timestamp: serverTimestamp(),
              changedBy: updatedBy,
              reason: this.getStatusChangeReason(updateData.status)
            }
          ]
        }
      }

      await updateDoc(appointmentRef, updates)

      // تحديث الإحصائيات في الوقت الفعلي
      await this.updateRealTimeStats()

      // إرسال إشعار
      if (updateData.status) {
        await this.sendAppointmentNotification(updateData.id, 'status_changed', updateData.status)
      }

      return { id: updateData.id, ...updates }
    } catch (error) {
      console.error('Error updating appointment:', error)
      throw error
    }
  }

  // حذف موعد
  async deleteAppointment(appointmentId: string, deletedBy: string) {
    try {
      const appointmentRef = doc(this.appointmentsCollection, appointmentId)
      const appointmentDoc = await getDoc(appointmentRef)

      if (!appointmentDoc.exists()) {
        throw new Error('الموعد غير موجود')
      }

      // تحديث الحالة إلى ملغي بدلاً من الحذف
      await this.updateAppointment({
        id: appointmentId,
        status: 'cancelled'
      }, deletedBy)

      // تحديث الإحصائيات
      await this.updateRealTimeStats()

      return true
    } catch (error) {
      console.error('Error deleting appointment:', error)
      throw error
    }
  }

  // الحصول على المواعيد مع التصفية
  async getAppointments(filters: AppointmentFilters = {}, pageSize = 20, lastDoc?: any) {
    try {
      let q = query(this.appointmentsCollection)

      // تطبيق الفلاتر
      if (filters.doctorId) {
        q = query(q, where('doctorId', '==', filters.doctorId))
      }
      if (filters.patientId) {
        q = query(q, where('patientId', '==', filters.patientId))
      }
      if (filters.status) {
        q = query(q, where('status.current', '==', filters.status))
      }
      if (filters.date) {
        q = query(q, where('date', '==', filters.date))
      }
      if (filters.type) {
        q = query(q, where('type', '==', filters.type))
      }

      // ترتيب حسب التاريخ والوقت
      q = query(q, orderBy('date', 'desc'), orderBy('time', 'desc'))

      // تطبيق التصفح
      if (lastDoc) {
        q = query(q, startAfter(lastDoc))
      }
      q = query(q, limit(pageSize))

      const snapshot = await getDocs(q)
      const appointments = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }))

      return {
        appointments,
        lastDoc: snapshot.docs[snapshot.docs.length - 1],
        hasMore: snapshot.docs.length === pageSize
      }
    } catch (error) {
      console.error('Error getting appointments:', error)
      throw error
    }
  }

  // التحقق من توفر الوقت
  async checkTimeSlotAvailability(doctorId: string, date: string, time: string): Promise<boolean> {
    try {
      const q = query(
        this.appointmentsCollection,
        where('doctorId', '==', doctorId),
        where('date', '==', date),
        where('time', '==', time),
        where('status.current', 'in', ['scheduled', 'confirmed', 'in-progress'])
      )

      const snapshot = await getDocs(q)
      return snapshot.empty
    } catch (error) {
      console.error('Error checking availability:', error)
      return false
    }
  }

  // الحصول على الأوقات المتاحة لطبيب في يوم معين
  async getAvailableTimeSlots(doctorId: string, date: string): Promise<TimeSlot[]> {
    try {
      // الحصول على بيانات الطبيب
      const doctorDoc = await getDoc(doc(this.doctorsCollection, doctorId))
      if (!doctorDoc.exists()) {
        throw new Error('الطبيب غير موجود')
      }

      const doctor = doctorDoc.data()
      const workingHours = doctor.scheduleInfo.workingHours
      const appointmentDuration = doctor.scheduleInfo.appointmentDuration || 30

      // إنشاء قائمة الأوقات المتاحة
      const timeSlots: TimeSlot[] = []
      const startTime = this.parseTime(workingHours.start)
      const endTime = this.parseTime(workingHours.end)

      for (let time = startTime; time < endTime; time += appointmentDuration) {
        const timeString = this.formatTime(time)
        timeSlots.push({
          time: timeString,
          available: true
        })
      }

      // التحقق من المواعيد المحجوزة
      const q = query(
        this.appointmentsCollection,
        where('doctorId', '==', doctorId),
        where('date', '==', date),
        where('status.current', 'in', ['scheduled', 'confirmed', 'in-progress'])
      )

      const snapshot = await getDocs(q)
      const bookedTimes = snapshot.docs.map(doc => {
        const data = doc.data()
        return {
          time: data.time,
          appointmentId: doc.id,
          patientName: data.patientName
        }
      })

      // تحديث حالة التوفر
      timeSlots.forEach(slot => {
        const bookedSlot = bookedTimes.find(booked => booked.time === slot.time)
        if (bookedSlot) {
          slot.available = false
          slot.appointmentId = bookedSlot.appointmentId
          slot.patientName = bookedSlot.patientName
        }
      })

      return timeSlots
    } catch (error) {
      console.error('Error getting available time slots:', error)
      throw error
    }
  }

  // إضافة إلى قائمة الانتظار
  async addToWaitingList(waitingListData: Omit<WaitingListEntry, 'createdAt'>) {
    try {
      const entry = {
        ...waitingListData,
        createdAt: serverTimestamp()
      }

      const docRef = await addDoc(this.waitingListCollection, entry)
      
      // إشعار عند توفر موعد
      await this.checkWaitingListForAvailability(waitingListData.doctorId)

      return { id: docRef.id, ...entry }
    } catch (error) {
      console.error('Error adding to waiting list:', error)
      throw error
    }
  }

  // إرسال التذكيرات
  async sendAppointmentReminders() {
    try {
      const tomorrow = new Date()
      tomorrow.setDate(tomorrow.getDate() + 1)
      const tomorrowString = tomorrow.toISOString().split('T')[0]

      const q = query(
        this.appointmentsCollection,
        where('date', '==', tomorrowString),
        where('status.current', 'in', ['scheduled', 'confirmed'])
      )

      const snapshot = await getDocs(q)
      const batch = writeBatch(db)

      for (const doc of snapshot.docs) {
        const appointment = doc.data()
        
        // إرسال تذكير
        await this.sendAppointmentNotification(doc.id, 'reminder')
        
        // تحديث عداد التذكيرات
        batch.update(doc.ref, {
          'metadata.remindersSent': appointment.metadata.remindersSent + 1
        })
      }

      await batch.commit()
      return snapshot.docs.length
    } catch (error) {
      console.error('Error sending reminders:', error)
      throw error
    }
  }

  // الاستماع للتحديثات الفورية
  subscribeToAppointmentUpdates(callback: (appointments: any[]) => void) {
    const q = query(
      this.appointmentsCollection,
      orderBy('metadata.updatedAt', 'desc'),
      limit(50)
    )

    return onSnapshot(q, (snapshot) => {
      const appointments = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }))
      callback(appointments)
    })
  }

  // تحديث الإحصائيات في الوقت الفعلي
  private async updateRealTimeStats() {
    try {
      const today = new Date().toISOString().split('T')[0]
      
      // إحصائيات اليوم
      const todayQuery = query(
        this.appointmentsCollection,
        where('date', '==', today)
      )
      
      const todaySnapshot = await getDocs(todayQuery)
      const todayStats = {
        total: todaySnapshot.size,
        completed: 0,
        pending: 0,
        cancelled: 0
      }

      todaySnapshot.docs.forEach(doc => {
        const status = doc.data().status.current
        if (status === 'completed') todayStats.completed++
        else if (status === 'cancelled') todayStats.cancelled++
        else todayStats.pending++
      })

      // تحديث في Realtime Database
      await set(ref(rtdb, 'stats/appointments/today'), todayStats)
    } catch (error) {
      console.error('Error updating real-time stats:', error)
    }
  }

  // إرسال إشعار
  private async sendAppointmentNotification(appointmentId: string, type: string, status?: string) {
    try {
      const appointmentDoc = await getDoc(doc(this.appointmentsCollection, appointmentId))
      if (!appointmentDoc.exists()) return

      const appointment = appointmentDoc.data()
      
      const notification = {
        type: `appointment_${type}`,
        appointmentId,
        patientId: appointment.patientId,
        doctorId: appointment.doctorId,
        message: this.getNotificationMessage(type, appointment, status),
        timestamp: Date.now()
      }

      // إرسال للمريض والطبيب
      await Promise.all([
        push(ref(rtdb, `notifications/${appointment.patientId}`), notification),
        push(ref(rtdb, `notifications/${appointment.doctorId}`), notification)
      ])
    } catch (error) {
      console.error('Error sending notification:', error)
    }
  }

  // التحقق من قائمة الانتظار عند توفر موعد
  private async checkWaitingListForAvailability(doctorId: string) {
    // تنفيذ منطق التحقق من قائمة الانتظار
    // وإشعار المرضى عند توفر مواعيد
  }

  // دوال مساعدة
  private parseTime(timeString: string): number {
    const [hours, minutes] = timeString.split(':').map(Number)
    return hours * 60 + minutes
  }

  private formatTime(minutes: number): string {
    const hours = Math.floor(minutes / 60)
    const mins = minutes % 60
    return `${hours.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}`
  }

  private getStatusChangeReason(status: string): string {
    const reasons = {
      confirmed: 'تأكيد الموعد',
      'in-progress': 'بدء الموعد',
      completed: 'انتهاء الموعد',
      cancelled: 'إلغاء الموعد',
      'no-show': 'عدم حضور المريض'
    }
    return reasons[status as keyof typeof reasons] || 'تحديث الحالة'
  }

  private getNotificationMessage(type: string, appointment: any, status?: string): string {
    switch (type) {
      case 'created':
        return `تم إنشاء موعد جديد مع د. ${appointment.doctorName}`
      case 'reminder':
        return `تذكير: لديك موعد غداً مع د. ${appointment.doctorName} في ${appointment.time}`
      case 'status_changed':
        return `تم تحديث حالة موعدك مع د. ${appointment.doctorName} إلى: ${status}`
      default:
        return 'تحديث في موعدك'
    }
  }
}

export const appointmentService = new AppointmentService()

