
"use server"

// AI-related actions are removed for now.
// We can re-add them later when connecting to a real backend.
